﻿
public interface Birthable
{
     string Birthday { get; }
}

