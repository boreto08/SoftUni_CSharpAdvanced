﻿
public interface Identifiable
{
     string Id { get; }
}

