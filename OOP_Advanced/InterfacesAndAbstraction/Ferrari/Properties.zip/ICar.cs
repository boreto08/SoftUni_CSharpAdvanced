﻿
public interface ICar
{
     string Driver { get; }

    string Stop();
    string Gas();
}

