﻿
using System.Collections.Generic;

public interface Browseable
{
    string Browse(string site);
}

