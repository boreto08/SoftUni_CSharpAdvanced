﻿
using System.Collections.Generic;

public interface Callable
{
    string Call(string number);
}

